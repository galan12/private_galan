nohup ./v2ray > nohup.out 2>&1 &
